params = {
    # params for the crypto stuff
    'b':10,
    'g':295,
    'p':587,
    # params for the Shamir Sharing
    'n':10,
    'k':5,
    # socket params
    'port':12345
}